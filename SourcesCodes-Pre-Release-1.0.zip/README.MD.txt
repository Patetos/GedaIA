Le codes sources n'est pas open sources.

Merci de ne pas vous en servir directement.
Mais plut�t de vous en inspirer.