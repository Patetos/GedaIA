﻿Public Class ia

    Dim ap = CreateObject("sapi.spvoice")
    Dim x As New Single

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        NotifyIcon1.ShowBalloonTip(1000)
    End Sub
    Private Sub NotifyIcon1_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        ' GEDA IA '

        If TextBox1.Text = "Géda" Then
            ap.speak("Je lance la page github du projet")
            Process.Start("https://github.com/Patetos/GedaIA/releases")
        End If
        If TextBox1.Text = "Projet" Then
            ap.speak("Je lance la page github du projet")
            Process.Start("https://github.com/Patetos/GedaIA/releases")
        End If
        If TextBox1.Text = "Projet page" Then
            ap.speak("Je lance la page github du projet")
            Process.Start("https://github.com/Patetos/GedaIA/releases")
        End If
        If TextBox1.Text = "Geda" Then
            ap.speak("Je lance la page github du projet")
            Process.Start("https://github.com/Patetos/GedaIA/releases")
        End If
        If TextBox1.Text = "Géda IA" Then
            ap.speak("Je lance la page github du projet")
            Process.Start("https://github.com/Patetos/GedaIA/releases")
        End If
        If TextBox1.Text = "Geda IA" Then
            ap.speak("Je lance la page github du projet")
            Process.Start("https://github.com/Patetos/GedaIA/releases")
        End If


        ' Présentation (Bonjour)

        If TextBox1.Text = "Bonjour" Then
            ap.speak("Bonjour ça va ?")
        End If
        If TextBox1.Text = "bonjour" Then
            ap.speak("Bonjour ça va ?")
        End If
        If TextBox1.Text = "BONJOUR" Then
            ap.speak("Bonjour ça va ?")
        End If


        ' SALUT '

        If TextBox1.Text = "Salut" Then
            ap.speak("Salut")
        End If
        If TextBox1.Text = "Salut" Then
            ap.speak("Salut")
        End If
        If TextBox1.Text = "Salut" Then
            ap.speak("Salut")
        End If


        ' WESH et YO '

        If TextBox1.Text = "Wesh" Then
            ap.speak("Wesh")
        End If
        If TextBox1.Text = "WESH" Then
            ap.speak("Wesh")
        End If
        If TextBox1.Text = "wesh" Then
            ap.speak("Wesh")
        End If

        If TextBox1.Text = "YO" Then
            ap.speak("Yo")
        End If
        If TextBox1.Text = "yo" Then
            ap.speak("Yo")
        End If
        If TextBox1.Text = "Yo" Then
            ap.speak("Yo")
        End If


        ' CA VA '

        If TextBox1.Text = "Oui et toi" Then
            ap.speak("Je ne suis qu'une intelligences artificielle donc je ne ressent pas d'émotions.")
        End If
        If TextBox1.Text = "Oui Et Toi" Then
            ap.speak("Je ne suis qu'une intelligences artificielle donc je ne ressent pas d'émotions.")
        End If
        If TextBox1.Text = "OUI ET TOI" Then
            ap.speak("Je ne suis qu'une intelligences artificielle donc je ne ressent pas d'émotions.")
        End If
        If TextBox1.Text = "oui et toi" Then
            ap.speak("Je ne suis qu'une intelligences artificielle donc je ne ressent pas d'émotions.")
        End If



        ' COMMENT T'APPELLE TU '

        If TextBox1.Text = "Comment t'appelles-tu" Or TextBox1.Text = "Comment t'appelles tu ?" Or TextBox1.Text = "Comment t'appelles tu" Or TextBox1.Text = "Quelle est ton nom ?" Or TextBox1.Text = "Quelle est ton nom" Or TextBox1.Text = "Qui est tu ?" Or TextBox1.Text = "Qui es tu" Or TextBox1.Text = "Qui es-tu ?" Or TextBox1.Text = "Qui es-tu" Then
            Randomize()
            x = Int(3 * Rnd() + 1)
            If x = 1 Then
                ap.speak("Je suis Géda")
            End If
            If x = 2 Then
                ap.speak("Géda")
            End If
            If x = 3 Then
                ap.speak("je m'appelle géda")
            End If
        End If



        'Ca va '

        If TextBox1.Text = "ça va" Or TextBox1.Text = "sa va" Or TextBox1.Text = "Sa va" Or TextBox1.Text = "Ca va" Or TextBox1.Text = "ca va" Then
            ap.speak("Je ne peut pas ressentir démossions désolés.")
        End If





        'Lancement de programme'

        'Partie WEB'
        If TextBox1.Text = "Facebook" Or TextBox1.Text = "FACEBOOK" Or TextBox1.Text = "facebook" Then
            ap.speak("Je lance Facebook tout de suite")
            Process.Start("https://www.facebook.com")
            ap.speak("Fait")
        End If
        If TextBox1.Text = "Google" Or TextBox1.Text = "GOOGLE" Or TextBox1.Text = "google" Then
            ap.speak("Je lance google tout de suite")
            Process.Start("https://www.google.fr")
            ap.speak("Fait")
        End If
    End Sub
End Class
